"""Only Multi-Products Examples"""

