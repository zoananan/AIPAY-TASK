"""Examples module"""

