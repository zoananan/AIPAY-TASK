"""Only Multi-Buyer Examples"""

